<?php
/**
Blog Booster v.1.0.0
@Proxtrasoft v.1.0.0
@license	: GNU Lesser General Public License v3.0 AND Proxtrasoft Moslem Opensource License
@author		: Abu Zidane Asadudin Shakir Al-Jabary
**/
$site = new Site();	
$includes	=	array("main","lang/".$site->lang);
$this->loadclass($includes);

?>