<?php
/**
Lite Notif v.1.1.0
@Proxtrasoft v.1.1.0
@license	: GNU Lesser General Public License v3.0 AND Halal Open Project License
@author		: Abu Zidane Asadudin Shakir Al-Jabary
**/
global $lang;
$lang['User_Management'] = array(
'title'=>'Pemberitahuan','subtitle'=>'Pemberitahuan web'
);
//print_r($lang);
?>